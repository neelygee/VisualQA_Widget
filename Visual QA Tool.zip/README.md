
  # Visual QA Tool

  This is a code bundle for Visual QA Tool. The original project is available at https://www.figma.com/design/B2Uf1KN6ruo5ZeFj300YM2/Visual-QA-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  